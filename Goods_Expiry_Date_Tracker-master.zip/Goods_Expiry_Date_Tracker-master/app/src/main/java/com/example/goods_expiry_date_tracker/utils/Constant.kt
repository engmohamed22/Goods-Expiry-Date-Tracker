package com.example.goods_expiry_date_tracker.utils

class Constant {
    companion object {
        const val TAG = "APP_DEBUG"
        const val NOTIFICATION_ID = 1
        const val CHANNEL_ID = "channel1"
    }
}
